package pl.dmcs.springbootjsp_iwa;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootJspIwaApplicationTests {

	@Test
	void contextLoads() {
	}

}
