package pl.dmcs.springbootjsp_iwa.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import pl.dmcs.springbootjsp_iwa.model.User;
import pl.dmcs.springbootjsp_iwa.repository.UserRepository;

@RestController
@CrossOrigin(origins = "http://localhost:4200")
@RequestMapping("/users")
public class UserRESTController {



    private UserRepository userRepository;


    @Autowired
    public UserRESTController(UserRepository userRepository) {
        this.userRepository = userRepository;
    }

    @RequestMapping(value="{username}", method = RequestMethod.GET, name = "getStudentById")
    public User getUserByUsername(@PathVariable("username") String username) {
        return userRepository.findByUsername(username).orElse(null);
    }



}
