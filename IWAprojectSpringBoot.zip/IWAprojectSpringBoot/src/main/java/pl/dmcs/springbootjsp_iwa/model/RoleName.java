package pl.dmcs.springbootjsp_iwa.model;

import jakarta.persistence.OneToOne;


public enum RoleName {

    STUDENT,
    TEACHER
}
