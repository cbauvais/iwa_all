import {User} from "./user/user.model";
import {Observable} from "rxjs";
import {Subject} from "./subject-detail/subject.model";

export class Grade {
  id?: number;
  grade: number;
  testName: string;
  comment: string;

  subject?: Subject;
  user?: User;


  constructor(testName: string, grade: number, comment: string, user: User, subject: Subject) {
    this.testName = testName;
    this.grade= grade;
    this.comment = comment;
    this.user = user;
    this.subject = subject;
  }

}
