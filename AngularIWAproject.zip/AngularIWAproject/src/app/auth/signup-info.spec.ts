import { SignupInfo } from './signup-info';

describe('SignupInfo', () => {
  it('should create an instance', () => {
    // @ts-ignore
    expect(new SignupInfo()).toBeTruthy();
  });
});
