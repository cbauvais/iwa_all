import {Component, OnInit} from '@angular/core';
import {UserService} from "../services/user.service";
import {SubjectService} from "../subject.service";
import {User} from "../user/user.model";
import {TokenStorageService} from "../auth/token-storage.service";
import {GradeService} from "../grade.service";
import {SignupInfo} from "../auth/signup-info";
import {Grade} from "../grade.model";
import {Subject} from "../subject-detail/subject.model";

@Component({
  selector: 'app-subjects',
  templateUrl: './subjects.component.html',
  styleUrls: ['./subjects.component.css']
})


export class SubjectsComponent implements OnInit {

  allSubjects?: Subject[];

  userSubjects?: Subject[];

  selectedSubject: any;
  form: any = {};
  subjectInfo?: Subject;
  isSignedUp = false;
  isSignUpFailed = false;
  errorMessage = '';
  info: any;

  //gradeToAdd?: Grade;



  constructor(private subjectService: SubjectService, private userService: UserService, private token: TokenStorageService, private gradeService: GradeService) { }

  ngOnInit() {
    this.getSubjects();

    this.getUserSubjects();

    this.info = {
      token: this.token.getToken(),
      username: this.token.getUsername(),
      authorities: this.token.getAuthorities(),
      id: this.token.getId()
    };



  }

  getSubjects(): void {
    this.subjectService.getSubjects().subscribe(allSubjects => {
      this.allSubjects = allSubjects;
      this.getUserSubjects();
    });
  }

  getUserSubjects(): void {
    if (!this.allSubjects) {
      return;
    }

    this.gradeService.getUserGrades(this.info.username).subscribe(userGrades => {
      const subjectIds = userGrades
        .filter(grade => grade.grade === -1)
        .map(grade => grade.subject?.id);
      console.log(userGrades)
      console.log(subjectIds);
      console.log(this.info.username);


      if(this.allSubjects){

          this.userSubjects = this.allSubjects.filter(subject => subjectIds.includes(subject.id));

      }

    });
  }

  onSubmit() {
    console.log(this.form);

    this.subjectInfo = new Subject(
      this.form.subjectName,
      this.form.description
    );


    this.subjectService.addSubject(this.subjectInfo).subscribe(
      data => {
        console.log(data);
        this.isSignedUp = true;
        this.isSignUpFailed = false;
        this.reloadPage();
      },
      error => {
        console.log(error);
        this.errorMessage = error.error.message;
        this.isSignUpFailed = true;
      }
    );
  }



  addSubject(subjectToAdd: string) {
    console.log(this.subjectService.getSubject(Number(subjectToAdd)));
    console.log(this.userService.getUserByUsername(this.info.username));
    this.userService.getUserByUsername(this.info.username).subscribe(
      user => {
        this.subjectService.getSubject(Number(subjectToAdd)).subscribe(
          subject => {
            const authoritiesString = this.info.authorities[0];
            const gradeToAdd = new Grade(
              'inscription',
              -1,
              authoritiesString,
              user,
              subject
            );
            console.log(user);
            console.log(subject);
            console.log(gradeToAdd);

            this.gradeService.addGrade(gradeToAdd).subscribe(
              () => {
                console.log('Grade added successfully');
                // Rechargez la page ou effectuez d'autres actions nécessaires après l'ajout de la note
                this.reloadPage();
              },
              error => {
                console.error('Error adding grade:', error);
              }
            );
          },
          error => {
            console.error('Error getting subject:', error);
          }
        );
      },
      error => {
        console.error('Error getting user:', error);
      }
    );
  }


  removeSubject(subjectToRemove: Subject) {
    const username = this.info.username;
    this.userService.getUserByUsername(username).subscribe(
      user => {
        const username = user.username;
        this.gradeService.getUserGrades(username).subscribe(
          grades => {
            const gradePromises = grades.map(grade => {
              if (grade.id !== undefined && grade.subject?.id === subjectToRemove.id) {
                return this.gradeService.deleteGrade(grade.id).toPromise();
              } else {
                console.log(grade.subject?.id);
                console.log(subjectToRemove.id);
                return Promise.resolve(); // Résolution immédiate de la promesse pour continuer la suppression des autres grades
              }
            });
            Promise.all(gradePromises)
              .then(() => {
                console.log('Grades removed successfully');
                this.reloadPage();
              })
              .catch(error => {
                console.error('Error removing grades:', error);
              });
          },
          error => {
            console.error('Error getting grades:', error);
          }
        );
      },
      error => {
        console.error('Error getting user:', error);
      }
    );
  }

  reloadPage() {
    window.location.reload();
  }
}

