import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from "@angular/common/http";

import {BehaviorSubject, catchError, Observable, of, tap} from "rxjs";

import {User} from "./user/user.model";
import {Grade} from "./grade.model";


const httpOptions= {
  headers: new HttpHeaders( {'Content-Type':'application/json' })
};

@Injectable({
  providedIn: 'root'
})
export class GradeService {

  private gradesUrl = 'http://localhost:8080/grades';
  private usersUrl = 'http://localhost:8080/users';
  constructor(private http: HttpClient) {


  }


  getUserGrades(username: string) {
    return this.http.get<Grade[]>(`${this.gradesUrl}/${username}`);
  }

  getGradeBySubject(subjectId: number){
    return this.http.get<Grade[]>(`${this.gradesUrl}/subject/${subjectId}`)
  }

  addGrade(gradeToAdd: Grade) {
    return this.http.post<Grade>(this.gradesUrl, gradeToAdd, httpOptions).pipe(
      tap((gradeAdded: Grade) => this.log(`added student id=${gradeAdded.id}`)))
  }

  deleteGrade(gradeId: number): Observable<void> {
    const url = `${this.gradesUrl}/${gradeId}`; // Supposant que vous avez une URL appropriée pour supprimer une note par son ID

    return this.http.delete<void>(url, httpOptions).pipe(
      tap(() => this.log(`deleted grade with id=${gradeId}`))
    );
  }
  private log(message: string) {
    console.log('StudentService: ' + message);
  }
}
