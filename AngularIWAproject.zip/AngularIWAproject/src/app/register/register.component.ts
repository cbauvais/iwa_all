import { Component, OnInit } from '@angular/core';
import {AuthService} from '../auth/auth.service';
import {SignupInfo} from '../auth/signup-info';
import {UserService} from "../services/user.service";

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {
  form: any = {};
  signupInfo?: SignupInfo;
  isSignedUp = false;
  isSignUpFailed = false;
  errorMessage = '';

  constructor(private authService: AuthService, private userService: UserService) { }

  ngOnInit() { }

  onSubmit() {
    console.log(this.form);

    if (this.form.teacherRole === 'teacher'){
      this.form.role = ["teacher"];
    }
    else{
      this.form.role = ["student"];
    }




    this.signupInfo = new SignupInfo(
      this.form.username,
      this.form.password,
      this.form.firstname,
      this.form.lastname,
      this.form.telephone,
      this.form.email,
      this.form.role
  );
    const emailPattern = /@/;
    if (this.form.firstname.length > 2 && this.form.lastname.length > 2 && emailPattern.test(this.form.email)) {
      // Les conditions sont satisfaites
      this.authService.signUp(this.signupInfo).subscribe(
        data => {
          console.log(data);
          this.isSignedUp = true;
          this.isSignUpFailed = false;
        },
        error => {
          console.log(error);
          this.errorMessage = error.error.message;
          this.isSignUpFailed = true;
        }
      );
      console.log("Les conditions sont satisfaites.");
    } else {
      // Les conditions ne sont pas satisfaites
      this.errorMessage = "error in the data you entered";
      this.isSignUpFailed = true;
      console.log("Les conditions ne sont pas satisfaites, registration failed.");
    }








  }



}
