import {Component, Input, ViewChild} from '@angular/core';
import {ActivatedRoute} from "@angular/router";
import {SubjectService} from "../subject.service";
import {Subject} from "./subject.model";
import {Location} from "@angular/common";
import {TokenStorageService} from "../auth/token-storage.service";
import {Grade} from "../grade.model";
import {User} from "../user/user.model";
import {UserService} from "../services/user.service";
import {GradeService} from "../grade.service";
import {NgModel} from "@angular/forms";
import {Observable, of, map} from "rxjs";
import {MatColumnDef, MatTableDataSource, MatTableModule} from '@angular/material/table';
import { MatInputModule } from '@angular/material/input';
import {MatSort, Sort} from '@angular/material/sort';
import { MatSortModule} from "@angular/material/sort";
import {LiveAnnouncer} from "@angular/cdk/a11y";


@Component({
  selector: 'app-subject-detail',
  templateUrl: './subject-detail.component.html',
  styleUrls: ['./subject-detail.component.css']
})



export class SubjectDetailComponent {
  @ViewChild(MatColumnDef) nameColumnDef!: MatColumnDef;



  @Input() subject?: Subject;
  info: any;
  form: any = {};
  isSignedUp = false;
  isSignUpFailed = false;
  errorMessage = '';
  studentsOfTheSubject: User[] = [];
  gradesOfTheSubject?: Grade[];

  studentGrades?: Grade[]

  sortColumn: string = 'name';
  sortDirection: string = 'asc';

  searchTerm: string = '';


  dataSource = new MatTableDataSource(this.studentsOfTheSubject);

  columns = [
    {
      columnDef: 'lastname',
      header: 'Participant',
      cell: (element: User) => `${element.lastname} `,
    },
    /*{
      columnDef: 'email',
      header: 'Email',
      cell: (element: User) => `${element.email}`,
    },*/
  ];



  displayedColumns = this.columns.map(c => c.columnDef);





  constructor(
    private route: ActivatedRoute,
    private subjectService: SubjectService,
    private location: Location,
    private token: TokenStorageService,
    private userService: UserService,
    private gradeService: GradeService,

    private _liveAnnouncer: LiveAnnouncer,


) {
    //this.sort = new MatSort();
  }



  @ViewChild('studentsTbSort') set matSort(sort: MatSort){
    this.dataSource.sort = sort;
  }
  ngAfterViewInit(): void {
    this.dataSource.sort = this.matSort;

    this.getSubject();

    this.dataSource = new MatTableDataSource(this.studentsOfTheSubject);

    // Activez le tri avec MatSort
    //this.dataSource.sort = this.sort;

    this.info = {
      token: this.token.getToken(),
      username: this.token.getUsername(),
      authorities: this.token.getAuthorities(),
      id: this.token.getId()
    };

    this.getStudentOfTheSubject();

    this.getGradesOfTheSubject(this.info.username);
  }

  /** Announce the change in sort state for assistive technology. */
  announceSortChange(sortState: Sort) {
    if (sortState.direction) {
      this._liveAnnouncer.announce(`Sorted ${sortState.direction}ending`);
    } else {
      this._liveAnnouncer.announce('Sorting cleared');
    }
  }


  filteredData: any[] = this.studentsOfTheSubject;

  applyFilter(event: Event) {
    const filterValue = (event.target as HTMLInputElement).value.trim().toLowerCase();

    // Filtrer les données sur la colonne "name"
    this.filteredData = this.studentsOfTheSubject.filter((row: any) =>
      row.name.toLowerCase().includes(filterValue)
    );
  }








  getSubject(): void {
    const id = Number(this.route.snapshot.paramMap.get('id'));
    this.subjectService.getSubject(id)
      .subscribe(subject => this.subject = subject);
  }


  goBack(): void {
    this.location.back();
  }

  addStudent(name: string, lastname: string) {
    this.userService.getUserByNames(name, lastname).subscribe(
      user => {
        if (this.subject && this.subject.id !== undefined) {
          this.subjectService.getSubject(this.subject.id).subscribe(
            subject => {
              const gradeToAdd = new Grade(
                'inscription',
                -1,
                'STUDENT',
                user,
                subject
              );
              console.log(user);
              console.log(subject);
              console.log(gradeToAdd);

              this.gradeService.addGrade(gradeToAdd).subscribe(
                () => {
                  console.log('Grade added successfully');
                  // Rechargez la page ou effectuez d'autres actions nécessaires après l'ajout de la note
                  this.reloadPage();
                },
                error => {
                  console.error('Error adding grade:', error);
                }
              );
            },
            error => {
              console.error('Error getting subject:', error);
            }
          );
        } else {
          console.error('Invalid subject ID');
        }
      },
      error => {
        console.error('Error getting user:', error);
      }
    );
  }

  getStudentOfTheSubject() {
    const subjectId = Number(this.route.snapshot.paramMap.get('id'));
    console.log(subjectId);

    if (subjectId !== undefined) {
      this.gradeService.getGradeBySubject(subjectId).subscribe(
        grades => {
          const students = grades
            .filter(grade => grade.grade === -1 && grade.comment === 'STUDENT')
            .map(grade => grade.user)
            .filter(user => user !== undefined) as User[];

          console.log(students);
          // Utilisez la liste des étudiants (students) comme souhaité
          this.studentsOfTheSubject = students;
          this.dataSource.data = this.studentsOfTheSubject;
        },

        error => {
          console.error('Error getting grades:', error);
        }
      );
    } else {
      console.error('Invalid subject ID');
    }
  }


  reloadPage() {
    window.location.reload();
  }



  //je n'arrive pas à faire une liste de grade pour chaque student
  getGrades(username: string): Observable<string> {
    const subjectId = Number(this.route.snapshot.paramMap.get('id'));

    if (subjectId !== undefined) {
      return this.gradeService.getUserGrades(username)
        .pipe(
          map(grades => {
            if (grades !== undefined) {
              const filteredGrades = grades.filter(
                grade => grade.subject?.id === subjectId && grade.grade >= 0
              );

              const formattedGrades = filteredGrades.map(
                grade => `${grade.grade.toFixed(2)}`
              );

              return formattedGrades.join(', ');
            } else {
              return '';
            }
          })
        );
    }

    return of('');
  }


  addNote(value: number, student: User, testName: string, comment: string ) {
    const subjectId = Number(this.route.snapshot.paramMap.get('id'));
          this.subjectService.getSubject(subjectId).subscribe(
            subject => {
              const gradeToAdd = new Grade(
                testName,
                value,
                comment,
                student,
                subject
              );
              console.log(subject);
              console.log(gradeToAdd);

              this.gradeService.addGrade(gradeToAdd).subscribe(
                () => {
                  console.log('Grade added successfully');
                  // Rechargez la page ou effectuez d'autres actions nécessaires après l'ajout de la note
                  this.reloadPage();
                },
                error => {
                  console.error('Error adding grade:', error);
                }
              );
            },
            error => {
              console.error('Error getting subject:', error);
            }
          );

      }

  getGradesOfTheSubject(username: string) {
    const subjectId = Number(this.route.snapshot.paramMap.get('id'));
    this.gradeService.getUserGrades(username).subscribe((grades) => {
      this.gradesOfTheSubject = grades.filter(
        (grade) =>
          grade.subject?.id === subjectId &&
          grade.grade >= 0
      );
    });
  }

  mean(): number {
    if(this.gradesOfTheSubject){
      if(this.gradesOfTheSubject.length == 0){
        return 0;
      }
      let sum = 0;
      for (let i = 0; i < this.gradesOfTheSubject.length; i++) {
        sum += this.gradesOfTheSubject[i].grade;
      }

      return sum / this.gradesOfTheSubject.length;
    }
    else{
      return 0;
    }
  }

  sortStudents() {
    if(this.studentsOfTheSubject){
      this.studentsOfTheSubject.sort((a, b) => {
        const nameA = a.firstname + ' ' + a.lastname;
        const nameB = b.firstname + ' ' + b.lastname;

        if (this.sortDirection === 'asc') {
          return nameA.localeCompare(nameB);
        } else {
          return nameB.localeCompare(nameA);
        }
      });
    }



  }

  get filteredStudents(): any[] {
    if(this.studentsOfTheSubject){
      return this.studentsOfTheSubject.filter(student => {
        const fullName = `${student.firstname} ${student.lastname}`.toLowerCase();
        return fullName.includes(this.searchTerm.toLowerCase());
      });
    }else{
      return [''];
    }

  }





  /*
  setmean(student: User): number{
    this.getGradesOfTheSubject(student.username);
    return this.mean();
  }
*/

  /*getStudentGradesOfTheSubject(username: string): Observable<Grade[]> {
    const subjectId = Number(this.route.snapshot.paramMap.get('id'));
    return this.gradeService.getUserGrades(username).pipe(
      map((grades) =>
        grades.filter((grade) => grade.subject?.id === subjectId && grade.grade >= 0)
      )
    );
  }*/



}
