export class Subject {
  id?: number;
  subjectName: string;
  description: string;

  constructor(subjectName: string, description: string) {
    this.subjectName = subjectName;
    this.description = description;
  }

}
