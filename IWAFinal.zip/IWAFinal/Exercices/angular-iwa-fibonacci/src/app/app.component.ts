import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-root',
  template: `
    <form>
      <div class="field">
        <label>
          Enter the number of iterations:
          <input type="number" #newIterations>
        </label>
      </div>

      <button (click)="generateFibonacci(newIterations)">Generate Fibonacci Sequence</button>
    </form>

    <div>
      <h2>Fibonacci Sequence:</h2>
      <ul>
        <li *ngFor="let number of fibonacciSequence">{{ number }}</li>
      </ul>
    </div>
  `,
})
export class AppComponent implements OnInit {
  numIterations: number;
  fibonacciSequence: number[];

  constructor(){
    this.numIterations = 0;
    this.fibonacciSequence =[];
  }

  ngOnInit(){}

  generateFibonacci(numIterations : HTMLInputElement) {
    console.log(`A number of iterations have been enter : ${numIterations.value}`);
    this.fibonacciSequence = [];
    let num1 = 0;
    let num2 = 1;

    for (let i = 0; i < parseInt(numIterations.value); i++) {
      this.fibonacciSequence.push(num1);
      let temp = num2;
      num2 = num1 + num2;
      num1 = temp;
    }
    return false;
  }
}
