package pl.dmcs.springbootjsp_iwa.controllers;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import pl.dmcs.springbootjsp_iwa.model.Quadratic;


@Controller
public class QuadraticController {
    @RequestMapping("/calculQuadratic")
    public String quadratic(Model model) {
        model.addAttribute("message", "Simple String from QuadraticController.");
        Quadratic newFunction = new Quadratic();
        model.addAttribute("quadratic", newFunction);
        return "quadratic";
    }

    @RequestMapping(value = "/calculQuadratic.html", method = RequestMethod.POST)
    public String addStudent(@ModelAttribute("quadratic") Quadratic quadratic){
        //add function quadratic
        double a = quadratic.getA(), b = quadratic.getB(), c = quadratic.getC();
        double delta, x, x1, x2;

            if ((a != 0) || (b != 0) || (c != 0)) {
                if (a == 0) {
                    if(b != 0){
                        x = -c / b;
                        System.out.println("The solution is" + x);
                    }
                    else{
                        System.out.println("No answer Possible");
                    }
                } else {
                    delta = b * b - 4 * a * c;
                    //System.out.println(delta);


                    if (delta < 0) {
                        //first case
                        System.out.println("There is no real solution");
                    } else if (delta == 0) {
                        //second case
                        x = -b / (2 * a);
                        System.out.println("The solution is" + x);
                    } else {
                        //third case
                        x1 = (-b - Math.sqrt(delta)) / (2 * a);
                        x2 = (-b + Math.sqrt(delta)) / (2 * a);
                        System.out.println("Solutions are : x1 = " + x1 + "; x2 = " + x2);
                    }
                }
            }
            else{
                System.out.println("ERROR : only 0 values");
            }

            return "redirect:calculQuadratic";

    }

}
