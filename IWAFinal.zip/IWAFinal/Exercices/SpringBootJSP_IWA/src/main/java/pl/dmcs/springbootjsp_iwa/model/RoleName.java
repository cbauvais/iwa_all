package pl.dmcs.springbootjsp_iwa.model;

public enum RoleName {
    ROLE_USER,
    ROLE_ADMIN
}
