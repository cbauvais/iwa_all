package pl.dmcs.springbootjsp_iwa.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import pl.dmcs.springbootjsp_iwa.model.Student;
import pl.dmcs.springbootjsp_iwa.model.Account;
import pl.dmcs.springbootjsp_iwa.repository.StudentRepository;
import pl.dmcs.springbootjsp_iwa.repository.AddressRepository;
import pl.dmcs.springbootjsp_iwa.repository.AccountRepository;

import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Optional;


@RestController
@RequestMapping("/account")
public class AccountRESTController {
/*
    private AccountRepository accountRepository;
    private StudentRepository studentRepository;


    @Autowired
    public AccountRESTController(StudentRepository studentRepository, AccountRepository accountRepository) {
        this.accountRepository = accountRepository;
        this.studentRepository = studentRepository;
    }

    //Find all accounts*/
    //@RequestMapping(method = RequestMethod.GET/*, produces = "application/xml"*/)
    //@GetMapping
    /*
    public List<Account> findAllAccounts() { return accountRepository.findAll();
    }

    //Find an account, enter the id of the account
    @RequestMapping(value="/{id}", method = RequestMethod.GET)
    public Account findOneAccount(@RequestBody Account account, @PathVariable("id") long id) { return accountRepository.findById(id);
    }


    //Find student associated to the account, enter the id of the account
    @RequestMapping(value="/{id}/student", method = RequestMethod.GET)
    public Student findAccountOfStudent(@PathVariable("id") long id) {

        return studentRepository.findByAccountId(id);
    }




    private void partialUpdate(Account account, Map<String, Object> updates) {
        if (updates.containsKey("accountName")) {
            account.setAccountName((String) updates.get("accountName"));
        }
        accountRepository.save(account);
    }

*/


}





