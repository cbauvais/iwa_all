-- to insert only if table is empty
INSERT INTO role (name) SELECT 'TEACHER' WHERE NOT EXISTS (SELECT * FROM role WHERE role.name='TEACHER');
INSERT INTO role (name) SELECT 'STUDENT' WHERE NOT EXISTS (SELECT * FROM role WHERE role.name='STUDENT');

-- FROM role;
--INSERT INTO role (name) VALUES ('TEACHER');
--INSERT INTO role (name) VALUES ('USER');
