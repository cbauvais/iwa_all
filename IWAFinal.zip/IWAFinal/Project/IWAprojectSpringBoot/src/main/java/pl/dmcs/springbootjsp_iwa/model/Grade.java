package pl.dmcs.springbootjsp_iwa.model;

import com.fasterxml.jackson.annotation.*;
import jakarta.persistence.*;
import org.springframework.jmx.export.annotation.ManagedAttribute;

@JsonIdentityInfo(generator = ObjectIdGenerators.PropertyGenerator.class, property = "id")
@Entity
public class Grade {
    @Id
    @GeneratedValue
    private long id;

    private String testName;
    private float grade;

    private String comment;

    @JsonProperty("user")
    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "user_id")
    //@JsonManagedReference
    private User user;


    @JsonProperty("subject")
    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "subject_id")
    //@JsonManagedReference
    private Subject subject;


    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getTestName() {
        return testName;
    }

    public void setTestName(String testName) {
        this.testName = testName;
    }

    public float getGrade() {
        return grade;
    }

    public void setGrade(float grade) {
        this.grade = grade;
    }

    public String getComment() {
        return comment;
    }

    public void setComment(String comment) {
        this.comment = comment;
    }

    public User getUser() {
        return user;
    }

    public void setUser(User user) {
        this.user = user;
    }

    public Subject getSubject() {
        return subject;
    }

    public void setSubject(Subject subject) {
        this.subject = subject;
    }
}
