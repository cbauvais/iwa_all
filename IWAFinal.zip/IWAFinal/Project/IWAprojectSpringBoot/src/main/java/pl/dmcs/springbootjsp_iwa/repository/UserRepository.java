package pl.dmcs.springbootjsp_iwa.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import pl.dmcs.springbootjsp_iwa.model.User;

import java.util.Optional;
import org.springframework.stereotype.Repository;
import pl.dmcs.springbootjsp_iwa.model.User;
@Repository
public interface UserRepository extends JpaRepository<User, Long> {
    Optional<User> findByUsername(String username);
    Boolean existsByUsername(String username);

    Optional<User> findByFirstnameAndLastname(String name, String lastname);
}
