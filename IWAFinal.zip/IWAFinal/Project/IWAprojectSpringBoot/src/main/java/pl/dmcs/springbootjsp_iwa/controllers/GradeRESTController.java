package pl.dmcs.springbootjsp_iwa.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import pl.dmcs.springbootjsp_iwa.model.Grade;
import pl.dmcs.springbootjsp_iwa.model.Subject;
import pl.dmcs.springbootjsp_iwa.repository.GradeRepository;
import pl.dmcs.springbootjsp_iwa.repository.SubjectRepository;

import java.util.List;

@RestController
@CrossOrigin(origins = "http://localhost:4200")
@RequestMapping("/grades")
public class GradeRESTController {

    private GradeRepository gradeRepository;



    @Autowired
    public GradeRESTController(GradeRepository gradeRepository) {
        this.gradeRepository = gradeRepository;
    }

    //add a grade

    @RequestMapping(method = RequestMethod.POST)
    //@PostMapping
    public ResponseEntity<Grade> addGrade(@RequestBody Grade grade) {
        gradeRepository.save(grade);
        return new ResponseEntity<Grade>(grade, HttpStatus.CREATED);
    }

    @RequestMapping(value= "/{user_username}", method = RequestMethod.GET)
    //@PostMapping
    public List<Grade> getGrade(@PathVariable("user_username") String user_username) {
        return gradeRepository.findByUserUsername(user_username);
    }

    @RequestMapping(value= "/subject/{subjectId}", method = RequestMethod.GET)
    //@PostMapping
    public List<Grade> getGrade(@PathVariable("subjectId") long subjectId) {
        return gradeRepository.findBySubjectId(subjectId);
    }


    @RequestMapping(method = RequestMethod.GET)
    //@PostMapping
    public List<Grade> getGrade() {
        return gradeRepository.findAll();
    }

    //delete a grade
    @RequestMapping(value="/{id}", method = RequestMethod.DELETE)
    public ResponseEntity<Subject> deleteSubject (@PathVariable("id") long id) {
        gradeRepository.deleteById(id);
        return new ResponseEntity<Subject>(HttpStatus.NO_CONTENT);
    }

}
