package pl.dmcs.springbootjsp_iwa.model;
import com.fasterxml.jackson.annotation.*;

import jakarta.persistence.*;

import java.util.ArrayList;
import java.util.List;

@Entity
public class Subject {

    @Id
    @GeneratedValue
    private long id;
    private String subjectName;

    private String description;



   @OneToMany(mappedBy = "subject", cascade = CascadeType.ALL, orphanRemoval = true)
   @JsonProperty("grades")
   @JsonBackReference
   private List<Grade> grades = new ArrayList<>();

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getSubjectName() {
        return subjectName;
    }

    public void setSubjectName(String subjectName) {
        this.subjectName = subjectName;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

   public List<Grade> getGrades() {
        return grades;
    }

    public void setGrades(List<Grade> grades) {
        this.grades = grades;
    }
}


