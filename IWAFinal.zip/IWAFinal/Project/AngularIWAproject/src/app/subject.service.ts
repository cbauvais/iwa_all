import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from "@angular/common/http";
import {BehaviorSubject, catchError, Observable, of, tap} from "rxjs";
import {Subject} from "./subject-detail/subject.model";


const httpOptions= {
  headers: new HttpHeaders( {'Content-Type':'application/json' })
};

@Injectable({
  providedIn: 'root'
})
export class SubjectService {

  private subjectUrl = 'http://localhost:8080/subjects';
  constructor(private http: HttpClient) {


  }

  getSubjects(): Observable<Subject[]>{
    return this.http.get<Subject[]>(this.subjectUrl);

  }

  getSubject(id: number): Observable<Subject>{
    return this.http.get<Subject>(`${this.subjectUrl}/${id}`);
  }

  getSubjectByName(name: string): Observable<Subject>{
    return this.http.get<Subject>(`${this.subjectUrl}/${name}`);
  }

  addSubject(subjectInfo: Subject) {
    return this.http.post<Subject>(this.subjectUrl, subjectInfo, httpOptions).pipe(
      tap((subjectAdded: Subject) => this.log(`added student id=${subjectAdded.id}`)))
  }

  private log(message: string) {
    console.log('StudentService: ' + message);
  }

/*
  getStudent(id: number): Observable<Student>{
    const url = `${this.studentsUrl}/${id}`;
    return this.http.get<Student>(url).pipe(
      tap( _ => this.log(`fetched student id=${id}`)),
      catchError(this.handleError<Student>(`getStudent id=${id}`))
    );
  }

  searchByLastname(lastname: string): Observable<Student[]> {
    const url = `${this.studentsUrl}/${lastname}`;
    return this.http.get<Student[]>(url);
  }



  updateStudent(student: Student, id: number): Observable<Student> {
    return this.http.put<Student>(`${this.studentsUrl}/${id}`, student, httpOptions).pipe(
      tap((studentUpdated: Student) => this.log(`updated student id=${studentUpdated.id}`)),
      catchError(this.handleError<any>('updateStudent'))
    )
  }

  partialUpdateStudent(updateData: Partial<Student>, id: number): Observable<Student> {
    const url = `${this.studentsUrl}/${id}`;
    return this.http.patch<Student>(url, updateData, httpOptions).pipe(
      tap((student: Student) => this.log(`partial updated student id=${student.id}`)),
      catchError(this.handleError<Student>('partialUpdateStudent'))
    );
  }


  addStudent(student: Student): Observable<Student> {
    return this.http.post<Student>(this.studentsUrl, student, httpOptions).pipe(
      tap((studentAdded: Student) => this.log(`added student id=${studentAdded.id}`))
      //catchError(this.handleError<Student>('addStudent'))
    )
  }*/

  /** DELETE: delete the student from the server */
  /*deleteStudent(student: Student | number): Observable<Student> {
    const id = typeof student === 'number' ? student : student.id;
    const url = `${this.studentsUrl}/${id}`;
    return this.http.delete<Student>(url, httpOptions).pipe(
      tap(_ => this.log(`deleted student id=${id}`)),
      catchError(this.handleError<Student>('deleteStudent'))
    );
  }*/

  /** DELETE: delete all the students from the server */
  /*deleteStudents(): Observable<Student> {
    return this.http.delete<Student>(this.studentsUrl, httpOptions).pipe(
      tap(_ => this.log(`deleted students`)),
      catchError(this.handleError<Student>('deleteStudents'))
    );
  }*/

  /**
   * Handle Http operation that failed.
   * Let the app continue.
   * @param operation - name of the operation that failed
   * @param result - optional value to return as the observable result
   */
  /*private handleError<T>(operation: string = 'operation', result?: T) {
    return (error: any): Observable<T> => {

      // TODO: send the error to remote logging infrastructure
      console.error(error); // log to console instead

      // TODO: better job of transforming error for user consumption
      this.log(`${operation} failed: ${error.message}`);

      // Let the app keep running by returning an empty result.
      return of(result as T);
    };
  }*/

  /** Log a StudentService message with the MessageService */
  /*private log(message: string) {
    console.log('StudentService: ' + message);
  }

  // for automatic update of number of students in parent component
  public totalItems: BehaviorSubject<number> = new BehaviorSubject<number>(0);
  getCartItems() {
    return this.totalItems.asObservable();
  }*/



}
