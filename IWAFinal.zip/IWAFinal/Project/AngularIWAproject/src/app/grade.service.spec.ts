import { TestBed } from '@angular/core/testing';

import {BehaviorSubject} from "rxjs";
import {GradeService} from "./grade.service";

describe('SubjectService', () => {
  let service: GradeService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(GradeService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });



});


