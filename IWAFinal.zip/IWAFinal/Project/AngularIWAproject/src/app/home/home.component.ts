import { Component, OnInit } from '@angular/core';
import {TokenStorageService} from "../auth/token-storage.service";
import {UserService} from "../services/user.service";


@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {

  info: any;

  constructor(private token: TokenStorageService) { }

  ngOnInit() {
    this.info = {
      token: this.token.getToken(),
      username: this.token.getUsername(),
      authorities: this.token.getAuthorities(),
      id: this.token.getId()
    };
  }

  logout() {
    this.token.signOut();
    window.location.reload();
  }

 /* getRegisteredId(username: string, authorities: any): void {
    if(authorities == "ROLE_USER"){
      //récupérer l'id du student
    }
    else{
      //récupérer l'id du teacher
      this.teacherService.getTeacherByUsername(username).subscribe(
        (teacher: Teacher) => {
          this.teacherInfo = teacher;
          console.log('ID du teacher :', this.teacherInfo.id);
        },
        (error) => {
          console.log('Erreur lors de la récupération du teacher :', error);
        }
      );
    }
  }*/
}
