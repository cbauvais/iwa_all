

export class User {
  id?: number;

  username: string;
  role: string;
  password: string;
  firstname: string;
  lastname: string;
  telephone: string;
  email: string;

  constructor(username: string, password: string, firstname: string, lastname: string, telephone: string, email: string, role: string) {
    this.username = username;
    this.password = password;
    this.firstname = firstname;
    this.lastname = lastname;
    this.telephone = telephone;
    this.email = email;
    this.role = role;
  }

}
