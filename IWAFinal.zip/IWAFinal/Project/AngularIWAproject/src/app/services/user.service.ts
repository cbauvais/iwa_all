import {Injectable, Optional} from '@angular/core';
import {Observable} from 'rxjs';
import {HttpClient} from '@angular/common/http';
import {User} from "../user/user.model";
import {Grade} from "../grade.model";



@Injectable({
  providedIn: 'root'
})
export class UserService {

  private userUrl = 'http://localhost:8080/Security/users';
  private usersUrl = 'http://localhost:8080/users';
  private adminUrl = 'http://localhost:8080/Security/admin';
  private gradeUrl = 'http://localhost:8080/Security/grades';
  private subjectUrl = 'http://localhost:8080/Security/subjects';

  constructor(private http: HttpClient) { }

  getUserPage(): Observable<string> {
    return this.http.get(this.userUrl, { responseType: 'text' });
  }

  getAdminPage(): Observable<string> {
    return this.http.get(this.adminUrl, { responseType: 'text' });
  }

  getSubjectPage(): Observable<string> {
    return this.http.get(this.subjectUrl, { responseType: 'text' });
  }

  getUserId(username: String): Observable<any>{
    const url = `${this.userUrl}/${username}`;
    return this.http.get(url);
  }

  getUserByUsername(username: string): Observable<User> {
    const url = `${this.usersUrl}/${username}`;
    return this.http.get<User>(url);
  }


  getUserByNames(studentName: string, studentLastname: string): Observable<User> {
    const url = `${this.usersUrl}/${studentName}/${studentLastname}`;
    return this.http.get<User>(url);
  }
}
